OD-WordPress-Whitelabel
=======================

A bunch of files to Whitelabel and Simplify WordPress for client sites.
