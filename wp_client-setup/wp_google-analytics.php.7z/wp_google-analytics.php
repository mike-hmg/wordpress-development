<?php
# Misc. WP `functions.php` goodies

// Add Google Analytics
<?php

add_action('wp_footer', 'add_googleanalytics');
	function add_googleanalytics() { ?>
// Paste your Google Analytics code from Step 6 here
	<?php UA-XXXX-XXXX} ?>

// add a favicon to your
function blog_favicon() {
echo '<link rel="Shortcut Icon" type="image/x-icon" href="'.get_bloginfo('wpurl').'http://cdn3.wpbeginner.com/favicon.ico" />';
}
add_action('wp_head', 'blog_favicon');

// Add custom dashboard LOGO
    add_action('admin_head', 'my_custom_logo');
    function my_custom_logo() {
    echo '
    <style type="text/css">
    #header-logo { background-image: url('.get_bloginfo('template_directory').'/images/custom-logo.gif) !important; }
    </style>
    ';
    }

// Remove the admin footer
function remove_footer_admin () {
    echo 'Fueled by <a href="http://www.wordpress.org" target="_blank">WordPress</a> | Designed by <a href="http://www.uzzz.net" target="_blank">Uzzz Productions</a> | WordPress Tutorials: <a href="http://www.wpbeginner.com" target="_blank">WPBeginner</a></p>';
    }

add_filter('admin_footer_text', 'remove_footer_admin');


    add_action('wp_dashboard_setup', 'my_custom_dashboard_widgets');

    function my_custom_dashboard_widgets() {
    global $wp_meta_boxes;

    wp_add_dashboard_widget('custom_help_widget', 'Theme Support', 'custom_dashboard_help');
    }

    function custom_dashboard_help() {
    echo '<p>Welcome to Custom Blog Theme! Need help? Contact the developer <a href="mailto:yourusername@gmail.com">here</a>. For WordPress Tutorials visit: <a href="http://www.wpbeginner.com" target="_blank">WPBeginner</a></p>';
    }
 ?>