<!--nav>
	<ul>
		<li><?php next_posts_link('&laquo; Older entries'); ?></li>
		<li><?php previous_posts_link('Newer entries &raquo;'); ?></li>
	</ul>
</nav-->
